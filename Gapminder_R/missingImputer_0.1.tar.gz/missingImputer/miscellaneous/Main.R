library(logging)
library(caret)
library(reshape2)
library(randomForest)
library(caTools)
library(Metrics)

directorio <- "~/Desktop/Data Science The Bridge/Repositorios GitHub/Repositorio_personal/R/gapminder/Gapminder_R/"

setwd(directorio)

lapply(paste0("R/", list.files(path = "R/", recursive = TRUE)), source)

debug(missingImputer)
missingImputer(path = directorio)
undebug(missingImputer)